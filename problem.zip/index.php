<?php


require(__DIR__.'/Problem0.php');
require (__DIR__ . '/vendor/autoload.php');

$problem = new Problem0();

$problem->getDataFromUrl();


?>