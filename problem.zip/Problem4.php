<?php

require(__DIR__.'/Problem.php');

/**
 * Finish implementation of Class Problem4 by having the method it must implement return the
 * solution to the following problem:
 *
 * Find all valid IP address combinations within a given string containing only digits.
 *
 * For example:
 *
 * $params[0] = '25525511135'
 * return ['255.255.11.135', '255.255.111.35']
 *
 */
class Problem4 implements Problem
{

}