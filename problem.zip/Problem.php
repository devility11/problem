<?php

interface Problem
{
    //public function run(...$params);
    //public function checkUrl(string $url): bool;
    public function getDataFromUrl();
    
}


?>

